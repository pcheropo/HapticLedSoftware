package com.example.android.bluetoothlegatt;

import android.content.Intent;
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class ScrollingActivityOptionsForVibration3 extends Activity {
    Button vibration;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scrolling_options_for_vibration3);
    }
    public void display_vibration(String inputEffect){
        ScrollingActivityOptionsForVibration.effect="M2" + inputEffect + "\n";
        MainActivity.sendBytesOfLight("M2" + inputEffect + "\n");
        StartingActivity.newSettingsObj.setVibr("M2" + inputEffect + "\n");
        startActivity(new Intent(ScrollingActivityOptionsForVibration3.this, confirmActivity.class));
    }
    public void transitionRampDownLongSmooth1100_0(View v) {
        vibration = (Button) findViewById(R.id.transitionRampDownLongSmooth1100_0ID);
        display_vibration("070");
    }
    public void transitionRampDownLongSmooth2100_0(View v) {
        vibration = (Button) findViewById(R.id.transitionRampDownLongSmooth2100_0ID);
        display_vibration("071");
    }
    public void transitionRampDownMediumSmooth1100_0(View v) {
        vibration = (Button) findViewById(R.id.transitionRampDownMediumSmooth1100_0ID);
        display_vibration("072");
    }
    public void transitionRampDownMediumSmooth2100_0(View v) {
        vibration = (Button) findViewById(R.id.transitionRampDownMediumSmooth2100_0ID);
        display_vibration("073");
    }
    public void transitionRampDownShortSmooth1100_0(View v) {
        vibration = (Button) findViewById(R.id.transitionRampDownShortSmooth1100_0ID);
        display_vibration("074");
    }

    public void transitionRampDownShortSmooth2100_0(View v) {
        vibration = (Button) findViewById(R.id.transitionRampDownShortSmooth2100_0ID);
        display_vibration("075");
    }

    public void transitionRampDownLongSharp1100_0(View v) {
        vibration = (Button) findViewById(R.id.transitionRampDownLongSharp1100_0ID);
        display_vibration("076");
    }

    public void transitionRampDownLongSharp2100_0(View v) {
        vibration = (Button) findViewById(R.id.transitionRampDownLongSharp2100_0ID);
        display_vibration("077");
    }

    public void transitionRampDownMediumSharp1100_0(View v) {
        vibration = (Button) findViewById(R.id.transitionRampDownMediumSharp1100_0ID);
        display_vibration("078");
    }

    public void transitionRampDownMediumSharp2100_0(View v) {
        vibration = (Button) findViewById(R.id.transitionRampDownMediumSharp2100_0ID);
        display_vibration("079");
    }

    public void transitionRampDownShortSharp1100_0(View v) {
        vibration = (Button) findViewById(R.id.transitionRampDownShortSharp1100_0ID);
        display_vibration("080");
    }

    public void transitionRampDownShortSharp2100_0(View v) {
        vibration = (Button) findViewById(R.id.transitionRampDownShortSharp2100_0ID);
        display_vibration("081");
    }

    public void transitionRampUpLongSmooth10_100(View v) {
        vibration = (Button) findViewById(R.id.transitionRampUpLongSmooth10_100ID);
        display_vibration("082");
    }
    public void transitionRampUpLongSmooth20_100(View v) {
        vibration = (Button) findViewById(R.id.transitionRampUpLongSmooth20_100ID);
        display_vibration("083");
    }
    public void transitionRampUpMediumSmooth10_100(View v) {
        vibration = (Button) findViewById(R.id.transitionRampUpMediumSmooth10_100ID);
        display_vibration("084");
    }
    public void transitionRampUpMediumSmooth20_100(View v) {
        vibration = (Button) findViewById(R.id.transitionRampUpMediumSmooth20_100ID);
        display_vibration("085");
    }
    public void transitionRampUpShortSmooth10_100(View v) {
        vibration = (Button) findViewById(R.id.transitionRampUpShortSmooth10_100ID);
        display_vibration("086");
    }
    public void transitionRampUpShortSmooth20_100(View v) {
        vibration = (Button) findViewById(R.id.transitionRampUpShortSmooth20_100ID);
        display_vibration("087");
    }
    public void transitionRampUpLongSharp10_100(View v) {
        vibration = (Button) findViewById(R.id.transitionRampUpLongSharp10_100ID);
        display_vibration("088");
    }
    public void transitionRampUpLongSharp20_100(View v) {
        vibration = (Button) findViewById(R.id.transitionRampUpLongSharp20_100ID);
        display_vibration("089");
    }
    public void transitionRampUpMediumSharp10_100(View v) {
        vibration = (Button) findViewById(R.id.transitionRampUpMediumSharp10_100ID);
        display_vibration("090");
    }
    public void transitionRampUpMediumSharp20_100(View v) {
        vibration = (Button) findViewById(R.id.transitionRampUpMediumSharp20_100ID);
        display_vibration("091");
    }
    public void transitionRampUpShortSharp10_100(View v) {
        vibration = (Button) findViewById(R.id.transitionRampUpShortSharp10_100ID);
        display_vibration("092");
    }
    public void transitionRampUpShortSharp20_100(View v) {
        vibration = (Button) findViewById(R.id.transitionRampUpShortSharp20_100ID);
        display_vibration("093");
    }
    public void transitionRampDownLongSmooth150_0(View v) {
        vibration = (Button) findViewById(R.id.transitionRampDownLongSmooth150_0ID);
        display_vibration("094");
    }
    public void transitionRampDownLongSmooth250_0(View v) {
        vibration = (Button) findViewById(R.id.transitionRampDownLongSmooth250_0ID);
        display_vibration("095");
    }
    public void transitionRampDownMediumSmooth150_0(View v) {
        vibration = (Button) findViewById(R.id.transitionRampDownMediumSmooth150_0ID);
        display_vibration("096");
    }
    public void transitionRampDownMediumSmooth250_0(View v) {
        vibration = (Button) findViewById(R.id.transitionRampDownMediumSmooth250_0ID);
        display_vibration("097");
    }
    public void transitionRampDownShortSmooth150_0(View v) {
        vibration = (Button) findViewById(R.id.transitionRampDownShortSmooth150_0ID);
        display_vibration("098");
    }
    public void transitionRampDownShortSmooth250_0(View v) {
        vibration = (Button) findViewById(R.id.transitionRampDownShortSmooth250_0ID);
        display_vibration("099");
    }
    public void transitionRampDownLongSharp150_0(View v) {
        vibration = (Button) findViewById(R.id.transitionRampDownLongSharp150_0ID);
        display_vibration("100");
    }
    public void transitionRampDownLongSharp250_0(View v) {
        vibration = (Button) findViewById(R.id.transitionRampDownLongSharp250_0ID);
        display_vibration("101");
    }
    public void transitionRampDownMediumSharp150_0(View v) {
        vibration = (Button) findViewById(R.id.transitionRampDownMediumSharp150_0ID);
        display_vibration("102");
    }
    public void transitionRampDownMediumSharp250_0(View v) {
        vibration = (Button) findViewById(R.id.transitionRampDownMediumSharp250_0ID);
        display_vibration("103");
    }
    public void transitionRampDownShortSharp150_0(View v) {
        vibration = (Button) findViewById(R.id.transitionRampDownShortSharp150_0ID);
        display_vibration("104");
    }
    public void transitionRampDownShortSharp250_0(View v) {
        vibration = (Button) findViewById(R.id.transitionRampDownShortSharp250_0ID);
        display_vibration("105");
    }
    public void transitionRampUpLongSmooth10_50(View v) {
        vibration = (Button) findViewById(R.id.transitionRampUpLongSmooth10_50ID);
        display_vibration("106");
    }
    public void transitionRampUpLongSmooth20_50(View v) {
        vibration = (Button) findViewById(R.id.transitionRampUpLongSmooth20_50ID);
        display_vibration("107");
    }
    public void transitionRampUpMediumSmooth10_50(View v) {
        vibration = (Button) findViewById(R.id.transitionRampUpMediumSmooth10_50ID);
        display_vibration("108");
    }
    public void transitionRampUpMediumSmooth20_50(View v) {
        vibration = (Button) findViewById(R.id.transitionRampUpMediumSmooth20_50ID);
        display_vibration("109");
    }
    public void transitionRampUpShortSmooth10_50(View v) {
        vibration = (Button) findViewById(R.id.transitionRampUpShortSmooth10_50ID);
        display_vibration("110");
    }
    public void transitionRampUpShortSmooth20_50(View v) {
        vibration = (Button) findViewById(R.id.transitionRampUpShortSmooth20_50ID);
        display_vibration("111");
    }
    public void transitionRampUpLongSharp10_50(View v) {
        vibration = (Button) findViewById(R.id.transitionRampUpLongSharp10_50ID);
        display_vibration("112");
    }
    public void transitionRampUpLongSharp20_50(View v) {
        vibration = (Button) findViewById(R.id.transitionRampUpLongSharp20_50ID);
        display_vibration("113");
    }
    public void transitionRampUpMediumSharp10_50(View v) {
        vibration = (Button) findViewById(R.id.transitionRampUpMediumSharp10_50ID);
        display_vibration("114");
    }
    public void transitionRampUpMediumSharp20_50(View v) {
        vibration = (Button) findViewById(R.id.transitionRampUpMediumSharp20_50ID);
        display_vibration("115");
    }
    public void transitionRampUpShortSharp10_50(View v) {
        vibration = (Button) findViewById(R.id.transitionRampUpShortSharp10_50ID);
        display_vibration("116");
    }
    public void transitionRampUpShortSharp20_50(View v) {
        vibration = (Button) findViewById(R.id.transitionRampUpShortSharp20_50ID);
        display_vibration("117");
    }

}
