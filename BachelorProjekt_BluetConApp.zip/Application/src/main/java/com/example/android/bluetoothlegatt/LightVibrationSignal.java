package com.example.android.bluetoothlegatt;
/*
We use this class to store all our settings
and it is the core of the entire App
 */
public class LightVibrationSignal {
       char colour;
       String Light;
       int millisec;
       int rep;
       String vibr;
       int tokkenForComp = 0 ;//repressents water,medical social act and so on starts always with water

        public void setTokken(int tokkenForComp){ this.tokkenForComp = tokkenForComp;}

        public void setColour(char colour){
            this.colour=colour;
        }

        public void setLight(String Light){
            this.Light=Light;
        }

        public void setMillisec(int millisec){
            this.millisec=millisec;
        }

        public void setRep(int rep){
            this.rep=rep;
        }

        public void setVibr(String vibr){
            this.vibr=vibr;
        }

        public int getTokken(){ return tokkenForComp;}

        public char getColour() {return colour; }

        public String getLig() {
            return Light;
        }
        
        public int getMill() {
            return millisec;
        }
        
        public int getRep() {
            return rep;
        }
        
        public String getVibr() {
            return this.vibr;
        }
}
