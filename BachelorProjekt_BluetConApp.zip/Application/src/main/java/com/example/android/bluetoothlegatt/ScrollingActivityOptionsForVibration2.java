package com.example.android.bluetoothlegatt;

import android.content.Intent;
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class ScrollingActivityOptionsForVibration2 extends Activity {
    Button vibration;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scrolling_options_for_vibration2);
    }

    public void display_vibration(String inputEffect){
        ScrollingActivityOptionsForVibration.effect="M2" + inputEffect + "\n";
        MainActivity.sendBytesOfLight("M2" + inputEffect + "\n");
        StartingActivity.newSettingsObj.setVibr("M2" + inputEffect + "\n");
        startActivity(new Intent(ScrollingActivityOptionsForVibration2.this, confirmActivity.class));
    }
    public void softBump100(View v) {
        vibration = (Button) findViewById(R.id.softBump100ID);
        display_vibration("007");
    }

    public void softBump60(View v) {
        vibration = (Button) findViewById(R.id.softBump60ID);
        display_vibration("008");
    }

    public void softBump30(View v) {
        vibration = (Button) findViewById(R.id.softBump30ID);
        display_vibration("009");
    }

    public void softFuzz60(View v) {
        vibration = (Button) findViewById(R.id.softFuzz60ID);
        display_vibration("013");
    }
    public void strongBuzz100(View v) {
        vibration = (Button) findViewById(R.id.strongBuzz100ID);
        display_vibration("014");
    }
    public void alert750ms(View v) {
        vibration = (Button) findViewById(R.id.alert750msID);
        display_vibration("015");
    }
    public void alert1000ms(View v) {
        vibration = (Button) findViewById(R.id.alert1000msID);
        display_vibration("016");
    }
    public void buzz1100(View v) {
        vibration = (Button) findViewById(R.id.buzz1100ID);
        display_vibration("047");
    }
    public void buzz280(View v) {
        vibration = (Button) findViewById(R.id.buzz280ID);
        display_vibration("048");
    }
    public void buzz360(View v) {
        vibration = (Button) findViewById(R.id.buzz360ID);
        display_vibration("049");
    }
    public void buzz440(View v) {
        vibration = (Button) findViewById(R.id.buzz440ID);
        display_vibration("050");
    }
    public void buzz520(View v) {
        vibration = (Button) findViewById(R.id.buzz520ID);
        display_vibration("051");
    }
    public void pulsingStrong1100(View v) {
        vibration = (Button) findViewById(R.id.pulsingStrong1100ID);
        display_vibration("052");
    }
    public void pulsingStrong280(View v) {
        vibration = (Button) findViewById(R.id.pulsingStrong280ID);
        display_vibration("053");
    }
    public void pulsingMedium1100(View v) {
        vibration = (Button) findViewById(R.id.pulsingMedium1100ID);
        display_vibration("054");
    }
    public void pulsingMedium260(View v) {
        vibration = (Button) findViewById(R.id.pulsingMedium260ID);
        display_vibration("055");
    }
    public void pulsingSharp1100(View v) {
        vibration = (Button) findViewById(R.id.pulsingSharp1100ID);
        display_vibration("056");
    }
    public void pulsingSharp260(View v) {
        vibration = (Button) findViewById(R.id.pulsingSharp260ID);
        display_vibration("057");
    }
    public void transitionHum1100(View v) {
        vibration = (Button) findViewById(R.id.transitionHum1100ID);
        display_vibration("064");
    }
    public void transitionHum280(View v) {
        vibration = (Button) findViewById(R.id.transitionHum280ID);
        display_vibration("065");
    }
    public void transitionHum360(View v) {
        vibration = (Button) findViewById(R.id.transitionHum360ID);
        display_vibration("066");
    }
    public void transitionHum440(View v) {
        vibration = (Button) findViewById(R.id.transitionHum440ID);
        display_vibration("067");
    }
    public void transitionHum520(View v) {
        vibration = (Button) findViewById(R.id.transitionHum520ID);
        display_vibration("068");
    }
    public void transitionHum610(View v) {
        vibration = (Button) findViewById(R.id.transitionHum610ID);
        display_vibration("069");
    }
    public void longBuzzforProgrammaticTopping100(View v) {
        vibration = (Button) findViewById(R.id.longBuzzforProgrammaticTopping100ID);
        display_vibration("118");
    }
    public void smoothHum50(View v) {
        vibration = (Button) findViewById(R.id.smoothHum50ID);
        display_vibration("119");
    }
    public void smoothHum40(View v) {
        vibration = (Button) findViewById(R.id.smoothHum40ID);
        display_vibration("120");
    }
    public void smoothHum30(View v) {
        vibration = (Button) findViewById(R.id.smoothHum30ID);
        display_vibration("121");
    }
    public void smoothHum20(View v) {
        vibration = (Button) findViewById(R.id.smoothHum20ID);
        display_vibration("122");
    }
    public void smoothHum10(View v) {
        vibration = (Button) findViewById(R.id.smoothHum10ID);
        display_vibration("123");
    }
}
