package com.example.android.bluetoothlegatt;

import android.content.Intent;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
public class patternSelection extends AppCompatActivity {
    Button LED;
    static boolean lightOrVibr ;
    public static String light = "L0000000000000000";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        lightOrVibr = true;
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pattern_selection);
    }

    public void led1(View v) {
        LED = (Button) findViewById(R.id.button1);
        generateLightPattern(0);
        MainActivity.sendBytesOfLight("L" + StartingActivity.newSettingsObj.getColour() + "000000000000000\n");
    }

    public void led2(View v) {
        LED = (Button) findViewById(R.id.button2);
        generateLightPattern(1);
        MainActivity.sendBytesOfLight("L0" + StartingActivity.newSettingsObj.getColour() + "00000000000000\n");
    }

    public void led3(View v) {
        LED = (Button) findViewById(R.id.button3);
        generateLightPattern(2);
        MainActivity.sendBytesOfLight("L00" + StartingActivity.newSettingsObj.getColour() + "0000000000000\n");
    }

    public void led4(View v) {
        LED = (Button) findViewById(R.id.button4);
        generateLightPattern(3);
        MainActivity.sendBytesOfLight("L000" + StartingActivity.newSettingsObj.getColour() + "000000000000\n");
    }

    public void led5(View v) {
        LED = (Button) findViewById(R.id.button5);
        generateLightPattern(4);
        MainActivity.sendBytesOfLight("L0000" + StartingActivity.newSettingsObj.getColour() + "00000000000\n");
    }

    public void led6(View v) {
        LED = (Button) findViewById(R.id.button6);
        generateLightPattern(5);
        MainActivity.sendBytesOfLight("L00000" + StartingActivity.newSettingsObj.getColour() + "0000000000\n");
    }

    public void led7(View v) {
        LED = (Button) findViewById(R.id.button7);
        generateLightPattern(6);
        MainActivity.sendBytesOfLight("L000000" + StartingActivity.newSettingsObj.getColour() + "000000000\n");
    }

    public void led8(View v) {
        LED = (Button) findViewById(R.id.button8);
        generateLightPattern(7);
        MainActivity.sendBytesOfLight("L0000000" + StartingActivity.newSettingsObj.getColour() + "00000000\n");
    }

    public void led9(View v) {
        LED = (Button) findViewById(R.id.button9);
        generateLightPattern(8);
        MainActivity.sendBytesOfLight("L00000000" + StartingActivity.newSettingsObj.getColour() + "0000000\n");
    }

    public void led10(View v) {
        LED = (Button) findViewById(R.id.button10);
        generateLightPattern(9);
        MainActivity.sendBytesOfLight("L000000000" + StartingActivity.newSettingsObj.getColour() + "000000\n");
    }

    public void led11(View v) {
        LED = (Button) findViewById(R.id.button11);
        generateLightPattern(10);
        MainActivity.sendBytesOfLight("L0000000000" + StartingActivity.newSettingsObj.getColour() + "00000\n");
    }

    public void led12(View v) {
        LED = (Button) findViewById(R.id.button12);
        generateLightPattern(11);
        MainActivity.sendBytesOfLight("L00000000000" + StartingActivity.newSettingsObj.getColour() + "0000\n");
    }

    public void led13(View v) {
        LED = (Button) findViewById(R.id.button13);
        generateLightPattern(12);
        MainActivity.sendBytesOfLight("L000000000000" + StartingActivity.newSettingsObj.getColour() + "000\n");
    }

    public void led14(View v) {
        LED = (Button) findViewById(R.id.button14);
        generateLightPattern(13);
        MainActivity.sendBytesOfLight("L0000000000000" + StartingActivity.newSettingsObj.getColour() + "00\n");
    }

    public void led15(View v) {
        LED = (Button) findViewById(R.id.button16);
        generateLightPattern(14);
        MainActivity.sendBytesOfLight("L00000000000000" + StartingActivity.newSettingsObj.getColour() + "0\n");
    }

    public void led16(View v) {
        LED = (Button) findViewById(R.id.button17);
        generateLightPattern(15);
        MainActivity.sendBytesOfLight("L000000000000000" + StartingActivity.newSettingsObj.getColour() + "\n");
    }

    public void reset(View v) {
        Button reset = (Button) findViewById(R.id.reset);
        StartingActivity.newSettingsObj.setLight(null);
    }

    public void finish(View v) {
        Button finish = (Button) findViewById(R.id.button18);
        StartingActivity.newSettingsObj.setLight(light);//save actual state
        MainActivity.sendBytesOfLight("L0000000000000000\n");
        startActivity(new Intent(patternSelection.this, confirmActivity.class));
    }

    public static void generateLightPattern(int index){
        String newLight = "" ;

        for(int i=0; i<light.length(); i++){
            if((index > 0 && index < 17) && (i == index)){
                newLight = newLight + StartingActivity.newSettingsObj.getColour();
            }else{
                newLight = newLight + light.charAt(i);
            }
        }

        light = newLight;
        StartingActivity.newSettingsObj.setLight(light);

    }
}
