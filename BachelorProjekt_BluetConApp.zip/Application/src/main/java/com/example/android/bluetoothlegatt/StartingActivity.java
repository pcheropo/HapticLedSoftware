package com.example.android.bluetoothlegatt;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import android.widget.Toast;
/*
This is the activity that we see when we first install the app
so you have to set our initial options in the begining otherwise
we can skip everything by selecting finish
 */
public class StartingActivity extends AppCompatActivity {
    Button colour, pattern, repetitions, distance_between_signals, vibration;
    TextView t;
    static LightVibrationSignal newSettingsObj = new LightVibrationSignal();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_starting);
        //every tokken references to a component
        if (DeviceControlActivity.tokkenForComp.getTokken() == 0) {
            t = (TextView) findViewById(R.id.textView2);
            t.setText("Set Settings for Water");
        } else if (DeviceControlActivity.tokkenForComp.getTokken() == 1) {
            t = (TextView) findViewById(R.id.textView2);
            t.setText("Set Settings for Medicine");
        } else if (DeviceControlActivity.tokkenForComp.getTokken() == 2) {
            t = (TextView) findViewById(R.id.textView2);
            t.setText("Set Settings for Physical Activity");
        } else if (DeviceControlActivity.tokkenForComp.getTokken() == 3) {
            t = (TextView) findViewById(R.id.textView2);
            t.setText("Set Settings for Sleeping");
        } else if (DeviceControlActivity.tokkenForComp.getTokken() == 4) {
            t = (TextView) findViewById(R.id.textView2);
            t.setText("Set Settings for Social Activity");
        }
    }

    public void colour(View v) {
        colour = (Button) findViewById(R.id.colourID);
        startActivity(new Intent(StartingActivity.this, colourSelection.class));
    }

    public void pattern(View v) {
        pattern = (Button) findViewById(R.id.PatternID);
        startActivity(new Intent(StartingActivity.this, patternSelection.class));
    }

    public void repetitions(View v) {
        repetitions = (Button) findViewById(R.id.repetitionsID);
        startActivity(new Intent(StartingActivity.this, repetitionSelection.class));
    }

    public void distance_between_signals(View v) {
        distance_between_signals = (Button) findViewById(R.id.distanceID);
        startActivity(new Intent(StartingActivity.this, distanceSelection.class));
    }

    public void vibration(View v) {
        vibration = (Button) findViewById(R.id.vibrID);
        startActivity(new Intent(StartingActivity.this, selectVibrationCategoryActivity.class));
    }

  /*In this function we compare the old signal Object fo´rom a component with the new one
  if any changes are done we override the old variables with the new ones if changes have
  been occured and we also check in the if this is the first session if yes then we have
  to set the settings for the other components to otherwise we continue with our main activity
  */
    public void finish(View v) {
        Button finish = (Button) findViewById(R.id.finish);
        String settings[] =  new String[]{String.valueOf(newSettingsObj.getColour()),newSettingsObj.getLig(), Integer.toString(newSettingsObj.getMill()), Integer.toString(newSettingsObj.getRep()), newSettingsObj.getVibr()};

        if (DeviceControlActivity.tokkenForComp.getTokken() == 0) {//water
            String oldSettings[] =  new String[]{String.valueOf(MainActivity.SettingsObjWater.getColour()),MainActivity.SettingsObjWater.getLig(),Integer.toString(MainActivity.SettingsObjWater.getMill()), Integer.toString(MainActivity.SettingsObjWater.getRep()), MainActivity.SettingsObjWater.getVibr()};
            saveSettings("settingsForWater.txt", settings, oldSettings);
            if(DeviceControlActivity.startOrMainFlag == 0) {
                DeviceControlActivity.tokkenForComp.setTokken(1);
            }
        } else if (DeviceControlActivity.tokkenForComp.getTokken() == 1) {//medicine
            String oldSettings[] =  new String[]{String.valueOf(MainActivity.SettingsObjMed.getColour()),MainActivity.SettingsObjMed.getLig(),Integer.toString(MainActivity.SettingsObjWater.getMill()), Integer.toString(MainActivity.SettingsObjMed.getRep()), MainActivity.SettingsObjMed.getVibr()};
            saveSettings("settingsForMedicine.txt", settings,oldSettings);
            if(DeviceControlActivity.startOrMainFlag == 0) {
                DeviceControlActivity.tokkenForComp.setTokken(2);
            }
        } else if (DeviceControlActivity.tokkenForComp.getTokken() == 2) {//Physical activity
            String oldSettings[] =  new String[]{String.valueOf(MainActivity.SettingsObjPhy.getColour()),MainActivity.SettingsObjPhy.getLig(),Integer.toString(MainActivity.SettingsObjWater.getMill()), Integer.toString(MainActivity.SettingsObjPhy.getRep()), MainActivity.SettingsObjPhy.getVibr()};
            saveSettings("settingsForPhysicalAct.txt", settings,oldSettings);
            if(DeviceControlActivity.startOrMainFlag == 0) {
                DeviceControlActivity.tokkenForComp.setTokken(3);
            }
        } else if (DeviceControlActivity.tokkenForComp.getTokken() == 3) {//sleeping
            String oldSettings[] =  new String[]{String.valueOf(MainActivity.SettingsObjSle.getColour()),MainActivity.SettingsObjSle.getLig(),Integer.toString(MainActivity.SettingsObjSle.getMill()), Integer.toString(MainActivity.SettingsObjSle.getRep()), MainActivity.SettingsObjSle.getVibr()};
            saveSettings("settingsForSleeping.txt", settings,oldSettings);
            if(DeviceControlActivity.startOrMainFlag == 0) {
                DeviceControlActivity.tokkenForComp.setTokken(4);
            }
        } else if (DeviceControlActivity.tokkenForComp.getTokken() == 4) {//social
            String oldSettings[] =  new String[]{String.valueOf(MainActivity.SettingsObjSoc.getColour()),MainActivity.SettingsObjSoc.getLig(),Integer.toString(MainActivity.SettingsObjSoc.getMill()), Integer.toString(MainActivity.SettingsObjSoc.getRep()), MainActivity.SettingsObjSoc.getVibr()};
            saveSettings("settingsForSocial.txt", settings,oldSettings);
            if(DeviceControlActivity.startOrMainFlag == 0) {
                DeviceControlActivity.tokkenForComp.setTokken(5);
            }
        }
        patternSelection.light="L0000000000000000";
        //reset new Settings object that is important because otherwise the next Component takes automaticaly values from this object
        newSettingsObj.setColour(' ');
        newSettingsObj.setLight(null);
        newSettingsObj.setRep(0);
        newSettingsObj.setMillisec(0);
        newSettingsObj.setVibr(null);
        //iterate over the settings of all the components
        if (DeviceControlActivity.tokkenForComp.getTokken() <= 5) {
            if(DeviceControlActivity.startOrMainFlag == 0){
                startActivity(new Intent(StartingActivity.this, StartingActivity.class));
            }else if(DeviceControlActivity.startOrMainFlag == 1){
                startActivity(new Intent(StartingActivity.this, MainActivity.class));
            }

        } else if (DeviceControlActivity.tokkenForComp.getTokken() == 5) {
            DeviceControlActivity.startOrMainFlag = 1;
            startActivity(new Intent(StartingActivity.this, MainActivity.class));
        }
    }

    /*
    here we give as an input the corresponding filename, the new and the old settings
    we check which part has changes and replace the old with the new ones and everything has
    to be written in a txt file in the data directory with the following format
    {colour}->1,2,3 ...
    {activated LEDs}->Lxxxxxxxxxxxxxxxxxx\n were x equals 0 or colour
    {repetitions}->integer that corresponds to how many times should be executed a signal
    {distance}->refers to the distance between the signal (sleep time in ms)
    {vibration}->M(1|2)xxx\n where xxx can be 001 to 123
     */
    private void saveSettings(String FILE_NAME, String settings[],String oldSettings[]) {
        FileOutputStream fos = null;
        try {
            fos = openFileOutput(FILE_NAME, MODE_PRIVATE);
            if(settings[0]==" " && (oldSettings[0]==" " || oldSettings[0]!=" ")){
                fos.write((oldSettings[0] + "\n").getBytes());
            }else if(settings[0]!=" " && (oldSettings[0]==" " || oldSettings[0]!=" ")){
                fos.write((settings[0] + "\n").getBytes());
            }

            if (settings[1] == null && (oldSettings[1] == null || oldSettings[1] != null)) {
                fos.write((oldSettings[1] + "\n").getBytes());
            } else if (settings[1] != null && (oldSettings[1] == null || oldSettings[1] != null)) {
                fos.write((settings[1] + "\n").getBytes());
            }

            for(int i=2; i<=3; i++) {
                if ((settings[i] == "0" || settings[i] == null )&& (oldSettings[i] == "0" || oldSettings[i] != "0")) {
                    fos.write((oldSettings[i] + "\n").getBytes());
                } else if ((settings[i] != "0" || settings[i] != null)&& (oldSettings[i] == "0" || oldSettings[i] != "0")) {
                    fos.write((settings[i] + "\n").getBytes());
                }
            }
            if (settings[4] == null && (oldSettings[4] == null || oldSettings[4] != null)) {
                fos.write((oldSettings[4] + "\n").getBytes());
            } else if (settings[4] != null && (oldSettings[4] == null || oldSettings[4] != null)) {
                fos.write((settings[4] + "\n").getBytes());
            }
            Toast.makeText(this, "Saved to " + getFilesDir() + "/" + FILE_NAME, Toast.LENGTH_LONG).show();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (fos != null) {
                try {
                    fos.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
