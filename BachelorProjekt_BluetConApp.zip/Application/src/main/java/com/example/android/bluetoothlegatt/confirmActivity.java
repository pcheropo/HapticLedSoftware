package com.example.android.bluetoothlegatt;

import android.content.Intent;
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
/*
this activity is used for the confirmation for light and vibration
 */
public class confirmActivity extends Activity {
    Button conf;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_strong_click4);
    }

    public void yes(View v) {
        conf = (Button) findViewById(R.id.button20);
        if(patternSelection.lightOrVibr==false) {
            StartingActivity.newSettingsObj.setVibr(ScrollingActivityOptionsForVibration.effect);
            startActivity(new Intent(confirmActivity.this, StartingActivity.class));
        }else{
            MainActivity.sendBytesOfLight(StartingActivity.newSettingsObj.getLig());
            try{
                Thread.sleep(500);
            }catch (Exception e){

            }
            MainActivity.sendBytesOfLight("L0000000000000000\n");
            startActivity(new Intent(confirmActivity.this, StartingActivity.class));
        }
    }
    public void no(View v) {
        conf = (Button) findViewById(R.id.button21);
        if(patternSelection.lightOrVibr==false) {
            startActivity(new Intent(confirmActivity.this, ScrollingActivityOptionsForVibration.class));
        }else{
            startActivity(new Intent(confirmActivity.this, patternSelection.class));
        }
    }
}
