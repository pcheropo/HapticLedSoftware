package com.example.android.bluetoothlegatt;

import android.content.Intent;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class selectVibrationCategoryActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        patternSelection.lightOrVibr = false;
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_motor);
    }

    public void clicks(View v) {
        Button clicks = (Button) findViewById(R.id.clicks);
        startActivity(new Intent(selectVibrationCategoryActivity.this ,ScrollingActivityOptionsForVibration.class));
    }

    public void other(View v) {
        Button other = (Button) findViewById(R.id.other);
        startActivity(new Intent(selectVibrationCategoryActivity.this ,ScrollingActivityOptionsForVibration2.class));
    }

    public void ramps(View v) {
        Button ramps = (Button) findViewById(R.id.ramps);
        startActivity(new Intent(selectVibrationCategoryActivity.this ,ScrollingActivityOptionsForVibration3.class));
    }

}
