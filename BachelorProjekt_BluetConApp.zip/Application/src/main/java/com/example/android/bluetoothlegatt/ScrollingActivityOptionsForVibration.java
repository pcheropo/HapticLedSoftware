package com.example.android.bluetoothlegatt;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.app.Activity;
import android.view.View;
import android.widget.Button;
/*
This class implements the Button for all vibration that we have according to the effect table from haptic
 */
public class ScrollingActivityOptionsForVibration extends Activity {
    Button vibration;
    static String effect = "";
    public static int flag =0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scrolling_options_for_vibration);
    }

    public void display_vibration(String inputEffect){
        effect = "M2" + inputEffect + "\n";
        MainActivity.sendBytesOfLight("M2" + inputEffect + "\n");
        StartingActivity.newSettingsObj.setVibr("M2" + inputEffect + "\n");
        startActivity(new Intent(ScrollingActivityOptionsForVibration.this, confirmActivity.class));
    }

    public void strongClick100(View v) {
        vibration = (Button) findViewById(R.id.strongClick100ID);
        display_vibration("001");
    }

    public void strongClick60(View v) {
        vibration = (Button) findViewById(R.id.strongClick60ID);
        display_vibration("002");
    }

    public void strongClick30(View v) {
        vibration = (Button) findViewById(R.id.strongClick30ID);
        display_vibration("003");
    }

    public void sharpClick100(View v) {
        vibration = (Button) findViewById(R.id.sharpClick100ID);
        display_vibration("004");
    }

    public void sharpClick60(View v) {
        vibration = (Button) findViewById(R.id.sharpClick60ID);
        display_vibration("005");
    }

    public void sharpClick30(View v) {
        vibration = (Button) findViewById(R.id.sharpClick30ID);
        display_vibration("006");
    }

    public void doubleClick100(View v) {
        vibration = (Button) findViewById(R.id.doubleClick100ID);
        display_vibration("010");
    }

    public void doubleClick60(View v) {
        vibration = (Button) findViewById(R.id.doubleClick60ID);
        display_vibration("011");
    }

    public void tripleClick100(View v) {
        vibration = (Button) findViewById(R.id.tripleClick100ID);
        display_vibration("012");
    }

    public void strongClick1100(View v) {
        vibration = (Button) findViewById(R.id.strongClick1100ID);
        display_vibration("017");
    }
    public void strongClick280(View v) {
        vibration = (Button) findViewById(R.id.strongClick280ID);
        display_vibration("018");
    }
    public void strongClick360(View v) {
        vibration = (Button) findViewById(R.id.strongClick360ID);
        display_vibration("019");
    }
    public void strongClick430(View v) {
        vibration = (Button) findViewById(R.id.strongClick430ID);
        display_vibration("020");
    }
    public void mediumClick1100(View v) {
        vibration = (Button) findViewById(R.id.mediumClick1100ID);
        display_vibration("021");
    }
    public void mediumClick280(View v) {
        vibration = (Button) findViewById(R.id.mediumClick280ID);
        display_vibration("022");
    }
    public void mediumClick360(View v) {
        vibration = (Button) findViewById(R.id.mediumClick360ID);
        display_vibration("023");
    }
    public void sharpTick1100(View v) {
        vibration = (Button) findViewById(R.id.sharpTick1100ID);
        display_vibration("024");
    }
    public void sharpTick280(View v) {
        vibration = (Button) findViewById(R.id.sharpTick280ID);
        display_vibration("025");
    }
    public void sharpTick360(View v) {
        vibration = (Button) findViewById(R.id.sharpTick360ID);
        display_vibration("026");
    }
    public void shortDoubleClickStrong1100(View v) {
        vibration = (Button) findViewById(R.id.shortDoubleClickStrong1100ID);
        display_vibration("027");
    }
    public void shortDoubleClickStrong280(View v) {
        vibration = (Button) findViewById(R.id.shortDoubleClickStrong280ID);
        display_vibration("028");
    }
    public void shortDoubleClickStrong360(View v) {
        vibration = (Button) findViewById(R.id.shortDoubleClickStrong360ID);
        display_vibration("029");
    }
    public void shortDoubleClickStrong430(View v) {
        vibration = (Button) findViewById(R.id.shortDoubleClickStrong430ID);
        display_vibration("030");
    }

    public void shortDoubleClickMedium100(View v) {
        vibration = (Button) findViewById(R.id.shortDoubleClickMedium100ID);
        display_vibration("031");
    }

    public void shortDoubleClickMedium80(View v) {
        vibration = (Button) findViewById(R.id.shortDoubleClickMedium80ID);
        display_vibration("032");
    }

    public void shortDoubleClickMedium60(View v) {
        vibration = (Button) findViewById(R.id.shortDoubleClickMedium60ID);
        display_vibration("033");
    }

    public void shortDoubleSharpTick1100(View v) {
        vibration = (Button) findViewById(R.id.shortDoubleSharpTick1100ID);
        display_vibration("034");
    }
    public void shortDoubleSharpTick280(View v) {
        vibration = (Button) findViewById(R.id.shortDoubleSharpTick280ID);
        display_vibration("035");
    }
    public void shortDoubleSharpTick360(View v) {
        vibration = (Button) findViewById(R.id.shortDoubleSharpTick360ID);
        display_vibration("036");
    }
    public void longDoubleSharpClickStrong1100(View v) {
        vibration = (Button) findViewById(R.id.longDoubleSharpClickStrong1100ID);
        display_vibration("037");
    }
    public void longDoubleSharpClickStrong280(View v) {
        vibration = (Button) findViewById(R.id.longDoubleSharpClickStrong280ID);
        display_vibration("038");
    }
    public void longDoubleSharpClickStrong360(View v) {
        vibration = (Button) findViewById(R.id.longDoubleSharpClickStrong360ID);
        display_vibration("039");
    }
    public void longDoubleSharpClickStrong430(View v) {
        vibration = (Button) findViewById(R.id.longDoubleSharpClickStrong430ID);
        display_vibration("040");
    }
    public void longDoubleSharpClickMedium1100(View v) {
        vibration = (Button) findViewById(R.id.longDoubleSharpClickMedium1100ID);
        display_vibration("041");
    }
    public void longDoubleSharpClickMedium280(View v) {
        vibration = (Button) findViewById(R.id.longDoubleSharpClickMedium280ID);
        display_vibration("042");
    }
    public void longDoubleSharpClickMedium360(View v) {
        vibration = (Button) findViewById(R.id.longDoubleSharpClickMedium360ID);
        display_vibration("043");
    }
    public void longDoubleSharpTick1100(View v) {
        vibration = (Button) findViewById(R.id.longDoubleSharpTick1100ID);
        display_vibration("044");
    }
    public void longDoubleSharpTick280(View v) {
        vibration = (Button) findViewById(R.id.longDoubleSharpTick280ID);
        display_vibration("045");
    }
    public void longDoubleSharpTick360(View v) {
        vibration = (Button) findViewById(R.id.longDoubleSharpTick360ID);
        display_vibration("046");
    }

    public void transitionClick1100(View v) {
        vibration = (Button) findViewById(R.id.transitionClick1100ID);
        display_vibration("058");
    }
    public void transitionClick280(View v) {
        vibration = (Button) findViewById(R.id.transitionClick280ID);
        display_vibration("059");
    }
    public void transitionClick360(View v) {
        vibration = (Button) findViewById(R.id.transitionClick360ID);
        display_vibration("060");
    }
    public void transitionClick440(View v) {
        vibration = (Button) findViewById(R.id.transitionClick440ID);
        display_vibration("061");
    }
    public void transitionClick520(View v) {
        vibration = (Button) findViewById(R.id.transitionClick520ID);
        display_vibration("062");
    }
    public void transitionClick610(View v) {
        vibration = (Button) findViewById(R.id.transitionClick610ID);
        display_vibration("063");
    }
}
