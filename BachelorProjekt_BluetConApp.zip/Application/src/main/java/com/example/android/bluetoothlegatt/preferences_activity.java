package com.example.android.bluetoothlegatt;

import android.content.Intent;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class preferences_activity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_preferences_activity);
    }

    public void save_as_preference(View v) {

    }

    public void view_preferences(View v) {

    }

    public void back_to_options(View v) {

    }

}
