package com.example.android.bluetoothlegatt;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.app.Activity;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import java.io.IOException;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;

public class MainActivity extends Activity {
    ImageButton i1;
    Button prev,next,options;
    TextView t1;
    String titleOfScreen = "";
    //here we create a unique object for every component such that they do not intefere or overide each others settings
    static LightVibrationSignal SettingsObjWater = new LightVibrationSignal();
    static LightVibrationSignal SettingsObjMed = new LightVibrationSignal();
    static LightVibrationSignal SettingsObjPhy = new LightVibrationSignal();
    static LightVibrationSignal SettingsObjSle= new LightVibrationSignal();
    static LightVibrationSignal SettingsObjSoc = new LightVibrationSignal();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        i1 = (ImageButton) findViewById(R.id.button2);
        prev = (Button) findViewById(R.id.button3);
        options = (Button) findViewById(R.id.button5);
        next = (Button) findViewById(R.id.button4);

        if(DeviceControlActivity.tokkenForComp.getTokken() == 0) {
            i1.setImageResource(R.drawable.water);
        }else if(DeviceControlActivity.tokkenForComp.getTokken() == 1) {
            i1.setImageResource(R.drawable.medicine);
        }else if(DeviceControlActivity.tokkenForComp.getTokken() == 2) {
            i1.setImageResource(R.drawable.physical);
        }else if(DeviceControlActivity.tokkenForComp.getTokken() == 3) {
            i1.setImageResource(R.drawable.sleeping);
        }else if(DeviceControlActivity.tokkenForComp.getTokken() == 4) {
            i1.setImageResource(R.drawable.social);
        }

    }

    public void initialise_button(View v){

        if(DeviceControlActivity.tokkenForComp.getTokken() == 5) {
            DeviceControlActivity.tokkenForComp.setTokken(0);//start from water again
        }
        i1 = (ImageButton) findViewById(R.id.button2);

        if(DeviceControlActivity.tokkenForComp.getTokken() == 0) {
            i1 = (ImageButton) findViewById(R.id.button2);
            load_and_send("settingsForWater.txt");

        }else if(DeviceControlActivity.tokkenForComp.getTokken() == 1) {
            i1 =  (ImageButton) findViewById(R.id.button2);
            load_and_send("settingsForMedicine.txt");
        }else if(DeviceControlActivity.tokkenForComp.getTokken() == 2) {
            i1 =  (ImageButton) findViewById(R.id.button2);
            load_and_send("settingsForPhysicalAct.txt");
        }else if(DeviceControlActivity.tokkenForComp.getTokken() == 3) {
            i1 = (ImageButton) findViewById(R.id.button2);
            load_and_send("settingsForSleeping.txt");
        }else if(DeviceControlActivity.tokkenForComp.getTokken() == 4) {
            i1 = (ImageButton) findViewById(R.id.button2);
            load_and_send("settingsForSocial.txt");
        }
    }

    public void load_and_send(String filename){
        LightVibrationSignal l = load(filename);//l
        sendBytesToDevice(l);
    }

    public void previous(View v){
        if(DeviceControlActivity.tokkenForComp.getTokken() == 0) {
            set_text_for_previous_next("social activity",4);
        }else if(DeviceControlActivity.tokkenForComp.getTokken() == 4) {
            set_text_for_previous_next("sleeping activity",3);
        }else if(DeviceControlActivity.tokkenForComp.getTokken() == 3) {
            set_text_for_previous_next("physical activity",2);
        }else if(DeviceControlActivity.tokkenForComp.getTokken() == 2) {
            set_text_for_previous_next("medicine",1);
        }else if(DeviceControlActivity.tokkenForComp.getTokken() == 1) {
            set_text_for_previous_next("water consuming",0);
        }
    }

    private void set_text_for_previous_next(String button_name,int frame_tokken){
        setNewTokken(frame_tokken,button_name);
    }

    public void options(View v){
        if(DeviceControlActivity.tokkenForComp.getTokken() == 0){
            SettingsObjWater = load("settingsForWater.txt");
            startActivity(new Intent(MainActivity.this, StartingActivity.class));
        }else if(DeviceControlActivity.tokkenForComp.getTokken() == 4){
            SettingsObjSoc = load("settingsForSocial.txt");
            startActivity(new Intent(MainActivity.this, StartingActivity.class));
        }else if(DeviceControlActivity.tokkenForComp.getTokken() == 3){
            SettingsObjSle = load("settingsForSleeping.txt");
            startActivity(new Intent(MainActivity.this, StartingActivity.class));
        }else if(DeviceControlActivity.tokkenForComp.getTokken() == 2){
            SettingsObjPhy = load("settingsForPhysicalAct.txt");
            startActivity(new Intent(MainActivity.this, StartingActivity.class));
        }else if(DeviceControlActivity.tokkenForComp.getTokken() == 1){
            SettingsObjMed = load("settingsForMedicine.txt");
            startActivity(new Intent(MainActivity.this, StartingActivity.class));
        }
    }

    public void setNewTokken(int i,String ButtonName){
        DeviceControlActivity.tokkenForComp.setTokken(i);
        startActivity(new Intent(MainActivity.this, MainActivity.class));
    }

    public void next(View v){
        if(DeviceControlActivity.tokkenForComp.getTokken() == 0) {
            set_text_for_previous_next("medicine",1);
        }else if(DeviceControlActivity.tokkenForComp.getTokken() == 1) {
            set_text_for_previous_next("physical activity",2);
        }else if(DeviceControlActivity.tokkenForComp.getTokken() == 2) {
            set_text_for_previous_next("sleeping activity",3);
        }else if(DeviceControlActivity.tokkenForComp.getTokken() == 3) {
            set_text_for_previous_next("social activity",4);
        }else if(DeviceControlActivity.tokkenForComp.getTokken() == 4) {
            set_text_for_previous_next("water consuming",0);
        }
    }

    public void sendBytesToDevice(LightVibrationSignal l){
        try {
        String off = "L0000000000000000\n";
        int i = 0;
        if(l.getRep()>= 1 && l.getRep()<=20){
           i =l.getRep();
        }else {
            i = 5;//default
        }

        while(i > 0) {
            if (l.getLig() != null && l.getLig().length() == 17) {
                sendBytesOfLight(l.getLig() + "\n");
            }else {//default
                if (DeviceControlActivity.tokkenForComp.getTokken() == 0) {//water
                    sendBytesOfLight("L4444444400000000\n");
                } else if (DeviceControlActivity.tokkenForComp.getTokken() == 4) {//social activity
                    sendBytesOfLight("L5555000055550000\n");
                } else if (DeviceControlActivity.tokkenForComp.getTokken() == 3) {//sleeping
                    sendBytesOfLight("L6666000000006666\n");
                } else if (DeviceControlActivity.tokkenForComp.getTokken() == 2) {//physical
                    sendBytesOfLight("L2200220022002200\n");
                } else if (DeviceControlActivity.tokkenForComp.getTokken() == 1) {//medicine
                    sendBytesOfLight("L1111111111111111\n");
                }
            }

            setSleep(l);

            if(l.getVibr()!=null && l.getVibr().length() == 5){
              sendBytesOfLight(l.getVibr() + "\n");
            }else{//default
              if(DeviceControlActivity.tokkenForComp.getTokken() == 4) {//water
                  sendBytesOfLight("M2031\n");
              }else if(DeviceControlActivity.tokkenForComp.getTokken() == 3) {//social activity
                  sendBytesOfLight("M2033\n");
              }else if(DeviceControlActivity.tokkenForComp.getTokken() == 2) {//sleeping
                  sendBytesOfLight("M2035\n");
              }else if(DeviceControlActivity.tokkenForComp.getTokken() == 1) {//physical
                  sendBytesOfLight("M2037\n");
              }else if(DeviceControlActivity.tokkenForComp.getTokken() == 0) {//medicine
                  sendBytesOfLight("M2039\n");
              }
            }
            setSleep(l);

            sendBytesOfLight(off);

            setSleep(l);

            i--;
        }} catch (Exception e) {
            // Toast.makeText(getApplicationContext(),e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private void setSleep(LightVibrationSignal l){
            try {
                if(l.getMill()>=100 && l.getMill()<=2000) {
                    Thread.sleep(l.getMill());
                }else {
                    Thread.sleep(1000);
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

    public static void sendBytesOfLight(String light){
        DeviceControlActivity.mNotifyCharacteristic.setValue(light.getBytes());
        BluetoothLeService.mBluetoothGatt.writeCharacteristic(DeviceControlActivity.mNotifyCharacteristic);
    }

    public LightVibrationSignal load(String filename) {
        FileInputStream fis = null;
        LightVibrationSignal l = new LightVibrationSignal();

        try {
            fis = openFileInput(filename);
            InputStreamReader isr = new InputStreamReader(fis);
            BufferedReader br = new BufferedReader(isr);
            StringBuilder sb = new StringBuilder();
            String text;
            int i = 0;
            while ((text = br.readLine()) != null) {
                sb.append(text).append("\n");
                if (i == 0) {
                    l.setColour(text.charAt(0));
                } else if (i == 1) {
                    l.setLight(text);
                } else if (i == 2) {
                    l.setMillisec(Integer.parseInt(text));
                } else if (i == 3) {
                    l.setRep(Integer.parseInt(text));
                } else if (i == 4) {
                    l.setVibr(text);
                }
                i++;
            }
        } catch (NumberFormatException e){
            e.printStackTrace();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (fis != null) {
                try {
                    fis.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        return l;
    }
}
