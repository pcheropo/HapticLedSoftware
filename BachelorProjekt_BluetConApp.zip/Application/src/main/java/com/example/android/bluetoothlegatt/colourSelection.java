package com.example.android.bluetoothlegatt;

import android.content.Intent;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

/*In this class we select the colour that we prefer
for the sake of simplicity it is possible to select only one
 */
public class colourSelection extends AppCompatActivity {

    Button colourB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_colour_selection);
    }
    public void red(View v) {
        colourB = (Button) findViewById(R.id.redID);
        StartingActivity.newSettingsObj.setColour('1');
        startActivity(new Intent(colourSelection.this, StartingActivity.class));
    }
    public void green(View v) {
        colourB = (Button) findViewById(R.id.greenID);
        StartingActivity.newSettingsObj.setColour('2');
        startActivity(new Intent(colourSelection.this, StartingActivity.class));
    }
    public void yellow(View v) {
        colourB = (Button) findViewById(R.id.yellowID);
        StartingActivity.newSettingsObj.setColour('3');
        startActivity(new Intent(colourSelection.this, StartingActivity.class));
    }
    public void blue(View v) {
        colourB = (Button) findViewById(R.id.blueID);
        StartingActivity.newSettingsObj.setColour('4');
        startActivity(new Intent(colourSelection.this, StartingActivity.class));
    }
    public void white(View v) {
        colourB = (Button) findViewById(R.id.whiteID);
        StartingActivity.newSettingsObj.setColour('5');
        startActivity(new Intent(colourSelection.this, StartingActivity.class));
    }
    public void purple(View v) {
        colourB = (Button) findViewById(R.id.purpleID);
        StartingActivity.newSettingsObj.setColour('6');
        startActivity(new Intent(colourSelection.this, StartingActivity.class));
    }

    public void non(View v) {
        colourB = (Button) findViewById(R.id.nonID);
        StartingActivity.newSettingsObj.setColour('0');
        startActivity(new Intent(colourSelection.this, StartingActivity.class));
    }
}
