package com.example.android.bluetoothlegatt;

import android.content.Intent;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class repetitionSelection extends AppCompatActivity {
    EditText mEditText;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_repetition_selection);
        mEditText = (EditText) findViewById(R.id.editText);
    }

    public void finish(View v) {
        final String text = mEditText.getText().toString();
        Button finish = (Button) findViewById(R.id.button19);
        if(text != "") {
            StartingActivity.newSettingsObj.setRep(Integer.parseInt(text));
            startActivity(new Intent(repetitionSelection.this, StartingActivity.class));
        }
    }
}
